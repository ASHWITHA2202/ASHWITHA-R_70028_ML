/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PatientData, PredictionResult, ModelContribution } from './types';

/**
 * Simulates a Decision Tree model focusing on high-impact rules.
 */
const ruleBasedHeuristic = (data: PatientData): ModelContribution => {
  let risk = 0;
  let reas = [];

  if (data.chestPainType === 'asymptomatic') { risk += 0.4; reas.push("Asymptomatic chest pain (silent indicator)"); }
  if (data.exerciseAngina) { risk += 0.3; reas.push("Exercise induced angina"); }
  if (data.oldpeak > 2) { risk += 0.3; reas.push("High ST depression (Oldpeak)"); }
  if (data.slope === 'downsloping') { risk += 0.2; reas.push("Downsloping ST segment"); }

  return {
    modelName: "Decision Tree (Rule-Based)",
    prediction: Math.min(risk, 1),
    weight: 0.35,
    reason: reas.length > 0 ? reas.join(", ") : "Normal rhythm and pain profiles detected."
  };
};

/**
 * Simulates a Logistic Regression model looking at linear correlations.
 */
const weightedProbability = (data: PatientData): ModelContribution => {
  let logit = -3.5; // Base log-odds
  
  logit += (data.age - 40) * 0.05;
  logit += data.sex === 'male' ? 0.8 : 0;
  logit += (data.restingBP - 120) * 0.02;
  logit += (data.cholesterol - 200) * 0.01;
  logit += data.fastingBS ? 0.5 : 0;
  if (data.restingECG !== 'normal') logit += 0.3;

  const risk = 1 / (1 + Math.exp(-logit));

  return {
    modelName: "Logistic Regressor (Linear)",
    prediction: risk,
    weight: 0.35,
    reason: `Analyzed ${data.age}y ${data.sex} profile with BP ${data.restingBP} and Chol ${data.cholesterol}.`
  };
};

/**
 * Simulates a Neural Network focusing on complex feature interactions.
 */
const interactionModel = (data: PatientData): ModelContribution => {
  let risk = 0.1;
  
  // High Age & Low MaxHR is a classic interaction
  if (data.age > 50 && data.maxHR < 130) risk += 0.4;
  
  // Cholesterol & BP interaction
  if (data.cholesterol > 240 && data.restingBP > 140) risk += 0.3;
  
  // slope & oldpeak interaction
  if (data.slope === 'downsloping' && data.oldpeak > 1.5) risk += 0.3;
  
  // Female & asymptomatic is rarer but serious
  if (data.sex === 'female' && data.chestPainType === 'asymptomatic') risk += 0.2;

  return {
    modelName: "Neural Net (Interactions)",
    prediction: Math.min(risk, 1),
    weight: 0.30,
    reason: "Identified non-linear risk factors across demographic and physiological bounds."
  };
};

export const runEnsemblePrediction = (data: PatientData): PredictionResult => {
  const m1 = ruleBasedHeuristic(data);
  const m2 = weightedProbability(data);
  const m3 = interactionModel(data);

  const weightedSum = (m1.prediction * m1.weight) + (m2.prediction * m2.weight) + (m3.prediction * m3.weight);
  
  let level: PredictionResult['level'] = 'Low';
  if (weightedSum > 0.8) level = 'Critical';
  else if (weightedSum > 0.6) level = 'High';
  else if (weightedSum > 0.3) level = 'Moderate';

  return {
    overallRisk: weightedSum,
    level,
    contributions: [m1, m2, m3],
    timestamp: new Date().toISOString()
  };
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import InputSection from './components/InputSection';
import ResultSection from './components/ResultSection';
import TestRuns from './components/TestRuns';
import InnovativeInsights from './components/InnovativeInsights';
import EvaluationFooter from './components/EvaluationFooter';
import { PatientData, PredictionResult } from './types';
import { INITIAL_PATIENT_DATA } from './constants';
import { runEnsemblePrediction } from './ensembleEngine';
import { getMedicalInsights } from './services/GeminiService';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, RefreshCcw, Info } from 'lucide-react';

export default function App() {
  const [patientData, setPatientData] = useState<PatientData>(INITIAL_PATIENT_DATA);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [insights, setInsights] = useState<any>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [showMentorMsg, setShowMentorMsg] = useState(true);

  const performInference = useCallback(async (data: PatientData) => {
    const res = runEnsemblePrediction(data);
    setPrediction(res);
    
    // Lazy load insights to prevent excessive API calls
    setLoadingInsights(true);
    const aiData = await getMedicalInsights(data, res);
    setInsights(aiData);
    setLoadingInsights(false);
  }, []);

  useEffect(() => {
    // Initial inference
    performInference(patientData);
  }, []);

  const handleDataChange = (newData: PatientData) => {
    setPatientData(newData);
    // Debounce or just trigger on change for demo
    performInference(newData);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 font-sans selection:bg-blue-500 selection:text-white relative overflow-hidden">
      {/* Background Blobs */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-40 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-emerald-500 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10">
        <Header bpm={patientData.maxHR} />

        <main className="max-w-7xl mx-auto px-6 py-12">
          {/* Mentor Onboarding */}
          <AnimatePresence>
            {showMentorMsg && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="mb-12 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 relative group"
              >
                <button 
                  onClick={() => setShowMentorMsg(false)}
                  className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors"
                >
                  <RefreshCcw className="w-4 h-4" />
                </button>
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(37,99,235,0.4)]">
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold tracking-tight mb-1 italic">Mentor Insight: Welcome to the Neural Simulation</h3>
                    <p className="text-sm text-slate-400 leading-relaxed max-w-2xl">
                      "We're testing a high-stakes ensemble learner today. Notice how the three models below interpret the patient data differently. The Linear Regressor looks at trends, while our Neural Interactions model hunts for dangerous pairings. Adjust the **Chest Pain Type** and **ST Depression** to see the ensemble logic shift in real-time. Ready to explore the future of diagnostics?"
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left Column: Form */}
            <div className="lg:col-span-7 space-y-8">
              <InputSection data={patientData} onChange={handleDataChange} />
              <InnovativeInsights insights={insights} loading={loadingInsights} />
            </div>

            {/* Right Column: Visualization */}
            <div className="lg:col-span-5 sticky top-8 space-y-8">
              <ResultSection result={prediction} />
              <TestRuns />
              
              {/* Quick Simulation Scenario info */}
              <div className="p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-xl flex gap-3 italic">
                 <Info className="w-4 h-4 text-blue-400 shrink-0" />
                 <p className="text-[10px] text-slate-500 leading-tight">
                   SIMULATION LAYER: This environment is currently processing simulated patient telemetry from Unit v2.4 nodes. All inference is computed locally using the validated ensemble architecture.
                 </p>
              </div>
            </div>
          </div>
        </main>

        <EvaluationFooter />
      </div>
    </div>
  );
}

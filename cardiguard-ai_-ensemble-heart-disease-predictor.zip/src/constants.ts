/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PatientData } from './types';

export const INITIAL_PATIENT_DATA: PatientData = {
  age: 45,
  sex: 'male',
  chestPainType: 'non-anginal',
  restingBP: 120,
  cholesterol: 200,
  fastingBS: false,
  restingECG: 'normal',
  maxHR: 150,
  exerciseAngina: false,
  oldpeak: 0,
  slope: 'flat',
};

export const RISK_LEVELS = {
  LOW: { label: 'Low', color: 'bg-emerald-500', text: 'text-emerald-400' },
  MODERATE: { label: 'Moderate', color: 'bg-blue-400', text: 'text-blue-400' },
  HIGH: { label: 'High', color: 'bg-blue-600', text: 'text-blue-500' },
  CRITICAL: { label: 'Critical', color: 'bg-orange-500', text: 'text-orange-500' },
};

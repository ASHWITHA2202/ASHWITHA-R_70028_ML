/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PatientData {
  age: number;
  sex: 'male' | 'female';
  chestPainType: 'typical' | 'atypical' | 'non-anginal' | 'asymptomatic';
  restingBP: number;
  cholesterol: number;
  fastingBS: boolean; // > 120 mg/dl
  restingECG: 'normal' | 'ST-T' | 'LVH';
  maxHR: number;
  exerciseAngina: boolean;
  oldpeak: number; // ST depression
  slope: 'upsloping' | 'flat' | 'downsloping';
}

export interface ModelContribution {
  modelName: string;
  prediction: number; // 0 to 1
  weight: number;
  reason: string;
}

export interface PredictionResult {
  overallRisk: number; // 0 to 1
  level: 'Low' | 'Moderate' | 'High' | 'Critical';
  contributions: ModelContribution[];
  timestamp: string;
}

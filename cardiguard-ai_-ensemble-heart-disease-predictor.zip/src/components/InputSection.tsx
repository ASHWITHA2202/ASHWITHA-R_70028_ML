/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PatientData } from '../types';
import { INITIAL_PATIENT_DATA } from '../constants';
import { User, Droplets, Gauge, Zap, LineChart, ChevronDown } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  data: PatientData;
  onChange: (data: PatientData) => void;
}

export default function InputSection({ data, onChange }: Props) {
  const handleChange = (field: keyof PatientData, value: any) => {
    onChange({ ...data, [field]: value });
  };

  return (
    <section className="bg-white/5 backdrop-blur-md p-6 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 select-none pointer-events-none">
        <span className="text-[40px] font-black opacity-5 italic leading-none text-white uppercase">Metrics</span>
      </div>

      <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-4">
        <User className="w-4 h-4 text-blue-400" />
        <h2 className="text-sm font-bold text-white uppercase tracking-widest italic">Patient Metrics Extraction</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Core Demographics */}
        <div className="space-y-6">
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Age Profile</span>
            <div className="flex items-center gap-4">
              <input 
                type="range" min="20" max="90" 
                value={data.age} 
                onChange={(e) => handleChange('age', parseInt(e.target.value))}
                className="flex-1 accent-blue-500 h-1 bg-white/10 rounded-full cursor-pointer"
              />
              <span className="font-mono text-white text-lg w-10 text-right">{data.age}</span>
            </div>
          </label>

          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Biological Sex</span>
            <div className="grid grid-cols-2 gap-2">
              {['male', 'female'].map((s) => (
                <button
                  key={s}
                  onClick={() => handleChange('sex', s as any)}
                  className={`py-2 text-[10px] font-bold uppercase tracking-widest rounded-lg border transition-all ${
                    data.sex === s 
                      ? 'bg-blue-500/10 border-blue-500 text-blue-400' 
                      : 'border-white/5 text-slate-500 hover:border-white/10'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </label>

          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10 transition-colors hover:bg-white/10">
             <div className="flex items-center gap-2">
               <Droplets className="w-4 h-4 text-blue-400" />
               <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Fasting Blood Sugar {'>'} 120</span>
             </div>
             <button 
              onClick={() => handleChange('fastingBS', !data.fastingBS)}
              className={`w-10 h-5 rounded-full relative transition-colors ${data.fastingBS ? 'bg-blue-500' : 'bg-slate-700'}`}
             >
               <motion.div 
                animate={{ x: data.fastingBS ? 22 : 2 }}
                className="absolute top-1 left-0 w-3 h-3 bg-white rounded-full shadow-sm" 
               />
             </button>
          </div>
        </div>

        {/* Vital Signs */}
        <div className="space-y-6">
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Resting Blood Pressure (mm Hg)</span>
            <div className="relative">
              <Gauge className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="number" 
                value={data.restingBP}
                onChange={(e) => handleChange('restingBP', parseInt(e.target.value) || 0)}
                className="w-full bg-slate-900/50 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-white font-mono text-sm focus:border-blue-500 outline-none transition-colors"
              />
            </div>
          </label>

          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Serum Cholesterol (mg/dl)</span>
            <div className="relative">
              <Droplets className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input 
                type="number" 
                value={data.cholesterol}
                onChange={(e) => handleChange('cholesterol', parseInt(e.target.value) || 0)}
                className="w-full bg-slate-900/50 border border-white/5 rounded-xl py-3 pl-10 pr-4 text-white font-mono text-sm focus:border-blue-500 outline-none transition-colors"
              />
            </div>
          </label>

          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Resting ECG Results</span>
            <div className="relative">
              <select 
                value={data.restingECG}
                onChange={(e) => handleChange('restingECG', e.target.value)}
                className="w-full bg-slate-900/50 border border-white/5 rounded-xl py-3 px-4 text-white font-mono text-xs focus:border-blue-500 outline-none transition-colors appearance-none cursor-pointer"
              >
                <option value="normal">Normal</option>
                <option value="ST-T">ST-T Wave Abnormality</option>
                <option value="LVH">Left Ventricular Hypertrophy</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
          </label>
        </div>

        {/* Clinical Observations */}
        <div className="space-y-6">
           <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Chest Pain Type</span>
            <div className="relative">
              <select 
                value={data.chestPainType}
                onChange={(e) => handleChange('chestPainType', e.target.value)}
                className="w-full bg-slate-900/50 border border-white/5 rounded-xl py-3 px-4 text-white font-mono text-xs focus:border-blue-500 outline-none transition-colors appearance-none cursor-pointer"
              >
                <option value="typical">Typical Angina</option>
                <option value="atypical">Atypical Angina</option>
                <option value="non-anginal">Non-Anginal Pain</option>
                <option value="asymptomatic">Asymptomatic</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
          </label>

          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10 transition-colors hover:bg-white/10">
             <div className="flex items-center gap-2">
               <Zap className="w-4 h-4 text-yellow-400" />
               <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Exercise Angina</span>
             </div>
             <button 
              onClick={() => handleChange('exerciseAngina', !data.exerciseAngina)}
              className={`w-10 h-5 rounded-full relative transition-colors ${data.exerciseAngina ? 'bg-blue-500' : 'bg-slate-700'}`}
             >
               <motion.div 
                animate={{ x: data.exerciseAngina ? 22 : 2 }}
                className="absolute top-1 left-0 w-3 h-3 bg-white rounded-full shadow-sm" 
               />
             </button>
          </div>

          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Peak Exercise ST Slope</span>
            <div className="relative">
              <select 
                value={data.slope}
                onChange={(e) => handleChange('slope', e.target.value)}
                className="w-full bg-slate-900/50 border border-white/5 rounded-xl py-3 px-4 text-white font-mono text-xs focus:border-blue-500 outline-none transition-colors appearance-none cursor-pointer"
              >
                <option value="upsloping">Upsloping</option>
                <option value="flat">Flat</option>
                <option value="downsloping">Downsloping</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
          </label>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-dashed border-white/5 grid grid-cols-1 md:grid-cols-2 gap-8">
         <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">Maximum Heart Rate Achieved</span>
            <input 
              type="range" min="60" max="220" 
              value={data.maxHR} 
              onChange={(e) => handleChange('maxHR', parseInt(e.target.value))}
              className="w-full accent-blue-500 h-1 bg-white/10 rounded-full cursor-pointer mb-2"
            />
            <div className="flex justify-between font-mono text-[10px] text-slate-500 italic uppercase">
              <span>60 BPM</span>
              <span className="text-white text-xs font-bold tracking-widest">{data.maxHR}</span>
              <span>220 BPM</span>
            </div>
          </label>

          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold mb-2 block">ST Depression (Oldpeak)</span>
            <input 
              type="range" min="0" max="6" step="0.1"
              value={data.oldpeak} 
              onChange={(e) => handleChange('oldpeak', parseFloat(e.target.value))}
              className="w-full accent-blue-500 h-1 bg-white/10 rounded-full cursor-pointer mb-2"
            />
            <div className="flex justify-between font-mono text-[10px] text-slate-500 italic uppercase">
              <span>0.0 (Normal)</span>
              <span className="text-white text-xs font-bold tracking-widest">{data.oldpeak.toFixed(1)}</span>
              <span>6.0 (Critical)</span>
            </div>
          </label>
      </div>
    </section>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HeartPulse, ShieldCheck, Activity } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  bpm: number;
}

export default function Header({ bpm }: Props) {
  // Calculate animation duration based on BPM (faster BPM = shorter duration)
  // 60 BPM = 1s cycle, 120 BPM = 0.5s cycle
  const beatDuration = 60 / Math.max(bpm, 40);

  return (
    <header className="border-b border-white/5 bg-white/5 backdrop-blur-md py-6 px-6 overflow-hidden relative">
      <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-blue-500 via-white/5 to-blue-500 opacity-30" />
      
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-4"
        >
          <motion.div 
            animate={{ 
              scale: [1, 1.15, 1],
              opacity: [1, 0.8, 1]
            }}
            transition={{ 
              repeat: Infinity, 
              duration: beatDuration,
              ease: "easeInOut"
            }}
            className="p-2 bg-blue-500 rounded-lg shadow-[0_0_20px_rgba(59,130,246,0.3)]"
          >
            <HeartPulse className="w-6 h-6 text-white" />
          </motion.div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              Heart Ensemble AI <span className="text-blue-400 font-mono text-[10px] px-2 py-0.5 border border-blue-500/30 bg-blue-500/10 rounded uppercase tracking-widest">v2.4.0</span>
            </h1>
            <div className="flex items-center gap-3">
              <p className="text-slate-400 text-xs font-medium uppercase tracking-wider opacity-60 italic whitespace-nowrap">Predictive Analysis Mode</p>
              <div className="h-1 w-1 rounded-full bg-slate-700" />
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono text-blue-400 font-bold">{bpm}</span>
                <span className="text-[9px] font-black text-slate-600 uppercase tracking-tighter">BPM</span>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center gap-4"
        >
          <div className="bg-white/5 border border-white/10 rounded-full px-4 py-2 flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-400 rounded-full shadow-[0_0_8px_rgba(52,211,153,0.5)] animate-pulse" />
            <span className="text-[10px] font-bold text-slate-100 uppercase tracking-widest">System Online</span>
          </div>
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-2 text-[10px] font-bold text-white uppercase tracking-widest">
            Expert Mode
          </div>
        </motion.div>
      </div>
    </header>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sparkles, Lightbulb, Rocket, Zap, Microscope } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  insights: any;
  loading: boolean;
}

export default function InnovativeInsights({ insights, loading }: Props) {
  if (loading) {
    return (
      <div className="p-8 border border-white/10 rounded-3xl bg-white/5 backdrop-blur-md flex flex-col items-center justify-center gap-4 text-slate-400 italic">
        <Sparkles className="w-8 h-8 animate-spin text-blue-500" />
        <span className="text-xs uppercase tracking-widest font-bold">Generating AI Clinical Analysis...</span>
      </div>
    );
  }

  if (!insights) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      <div className="flex items-center gap-4 px-2">
        <div className="h-px flex-1 bg-gradient-to-r from-transparent to-blue-500/20" />
        <div className="flex items-center gap-2">
          <Microscope className="w-4 h-4 text-blue-500" />
          <h2 className="text-[10px] uppercase tracking-[0.4em] font-black text-blue-400">Innovation Hub</h2>
        </div>
        <div className="h-px flex-1 bg-gradient-to-l from-transparent to-blue-500/20" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Context & Case Study */}
        <div className="space-y-6">
          <section className="bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-2xl relative overflow-hidden group">
            <div className="absolute -top-4 -right-4 w-12 h-12 bg-blue-500/5 blur-xl group-hover:bg-blue-500/10 transition-colors" />
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-4 h-4 text-blue-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-widest">Clinical Synthesis</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed italic">
              "{insights.medicalContext || "No clinical context available."}"
            </p>
          </section>

          <section className="bg-slate-900/30 border border-white/5 p-6 rounded-2xl border-l-2 border-l-blue-500">
             <h4 className="text-[10px] uppercase tracking-widest text-slate-500 mb-3 font-mono">Case Study: Deployment Unit 402</h4>
             <p className="text-[10px] text-slate-400 leading-relaxed italic">
               {insights.caseStudyScenario || "Scenario analysis pending..."}
             </p>
          </section>
        </div>

        {/* Futuristic Extensions & Optimization */}
        <div className="space-y-6">
           <section className="bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-2xl">
              <div className="flex items-center gap-2 mb-4">
                <Rocket className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-widest">Futuristic Roadmap</h3>
              </div>
              <ul className="space-y-3">
                {(insights.innovativeExtensions || []).map((ext: string, i: number) => (
                  <motion.li 
                    key={i}
                    whileHover={{ x: 4 }}
                    className="flex gap-3 text-[10px] text-slate-400 items-start"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1 flex-shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.5)]" />
                    <span>{ext}</span>
                  </motion.li>
                ))}
              </ul>
           </section>

           <section className="p-6 bg-slate-900/50 border border-white/5 rounded-2xl">
              <div className="flex items-center gap-2 mb-4">
                <Lightbulb className="w-4 h-4 text-yellow-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-widest">Model Alpha Tuning</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {(insights.optimizationTricks || []).map((trick: string, i: number) => (
                  <span key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded-md text-[9px] text-slate-400 font-bold uppercase tracking-tighter">
                    {trick}
                  </span>
                ))}
              </div>
           </section>
        </div>
      </div>
    </motion.div>
  );
}

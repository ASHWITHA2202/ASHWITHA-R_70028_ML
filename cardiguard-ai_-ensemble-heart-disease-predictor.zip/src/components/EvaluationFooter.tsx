/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CheckCircle2, Wrench, Lightbulb, AlertTriangle, Rocket } from 'lucide-react';

export default function EvaluationFooter() {
  const sections = [
    { 
      title: "Objectives", 
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-500" />,
      tag: "✅",
      content: "Democratize high-fidelity cardiac risk assessment through multi-model consensus, reducing false negatives in early stage heart disease detection."
    },
    { 
      title: "Methods", 
      icon: <Wrench className="w-4 h-4 text-blue-500" />,
      tag: "🔧",
      content: "Ensemble learning architecture combining Heuristic Decision Trees, Logistic Probabilities, and non-linear Neural Interaction detection."
    },
    { 
      title: "Benefits", 
      icon: <Lightbulb className="w-4 h-4 text-yellow-500" />,
      tag: "💡",
      content: "Increased diagnostic robustness, transparency in 'voting' logic (Explainable AI), and real-time inference on complex physiological data."
    },
    { 
      title: "Challenges", 
      icon: <AlertTriangle className="w-4 h-4 text-orange-500" />,
      tag: "⚠️",
      content: "Data noise in patient-reported metrics requires aggressive sensor calibration and multi-source verification to maintain accuracy."
    },
    { 
      title: "Future Scope", 
      icon: <Rocket className="w-4 h-4 text-red-500" />,
      tag: "🚀",
      content: "Federated learning across clinical networks and integration with wearable bio-sensors for longitudinal risk trajectory tracking."
    }
  ];

  return (
    <footer className="mt-20 border-t border-white/5 pt-12 pb-20 bg-white/5 backdrop-blur-xl px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-12">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 uppercase font-black tracking-[0.2em] mb-1">Ensemble State</span>
            <span className="text-xs text-white font-bold tracking-tight">Heterogeneous Voting Architecture</span>
          </div>
          <div className="text-center">
             <h2 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.5em] mb-2 font-mono">Expert Evaluation Readiness</h2>
             <div className="h-0.5 w-12 bg-blue-500 mx-auto opacity-50" />
          </div>
          <div className="flex flex-col text-right">
            <span className="text-[10px] text-slate-500 uppercase font-black tracking-[0.2em] mb-1">Validation Split</span>
            <span className="text-xs text-white font-bold tracking-tight">K-Fold (K=10) Validation</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
           {sections.map((section, idx) => (
             <div key={idx} className="group relative p-4 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-colors">
                <div className="flex items-center gap-2 mb-3">
                  {section.icon}
                  <span className="text-[10px] font-bold text-white uppercase tracking-widest">{section.title}</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed font-medium group-hover:text-slate-400 transition-colors">
                   {section.content}
                </p>
                <div className="absolute top-2 right-2 text-[10px] opacity-10 group-hover:opacity-100 transition-opacity">
                  {section.tag}
                </div>
             </div>
           ))}
        </div>
      </div>
    </footer>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PredictionResult } from '../types';
import { RISK_LEVELS } from '../constants';
import { AlertCircle, TrendingUp, Info, BarChart3, BrainCircuit } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  result: PredictionResult | null;
}

export default function ResultSection({ result }: Props) {
  if (!result) return (
    <div className="h-full flex items-center justify-center p-12 border-2 border-dashed border-zinc-800 rounded-3xl opacity-50 italic text-zinc-500 font-serif">
      Waiting for sensor calibration and data input...
    </div>
  );

  const riskInfo = result.level === 'Low' ? RISK_LEVELS.LOW :
                  result.level === 'Moderate' ? RISK_LEVELS.MODERATE :
                  result.level === 'High' ? RISK_LEVELS.HIGH : RISK_LEVELS.CRITICAL;

  return (
    <div className="space-y-6">
      {/* Risk Overview Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 relative overflow-hidden shadow-2xl"
      >
        <div className={`absolute top-0 right-0 w-32 h-32 blur-[80px] opacity-10 ${riskInfo.color}`} />
        <div className="absolute top-0 right-10 p-4 select-none pointer-events-none">
          <span className="text-[60px] font-black opacity-5 italic leading-none text-white uppercase">Result</span>
        </div>
        
        <div className="flex justify-between items-start mb-6">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Aggregated Risk Factor</span>
            <h3 className={`text-4xl font-black tracking-tighter ${riskInfo.text} mt-1`}>
              {result.level.toUpperCase()}
            </h3>
          </div>
          <div className="text-right">
            <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Confidence Coefficient</span>
            <div className="text-2xl font-mono text-white mt-1">{(result.overallRisk * 100).toFixed(1)}%</div>
          </div>
        </div>

        <div className="relative h-4 bg-slate-900/50 rounded-full overflow-hidden border border-white/5 shadow-inner">
           <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${result.overallRisk * 100}%` }}
            transition={{ type: "spring", bounce: 0.2 }}
            className={`h-full ${riskInfo.color} relative`}
           >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" />
           </motion.div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
           <div className="p-3 bg-white/5 rounded-lg border border-white/5 flex gap-3 items-center">
              <AlertCircle className="w-4 h-4 text-blue-400" />
              <p className="text-[10px] text-slate-400 leading-relaxed uppercase tracking-tight">
                <span className="text-white font-bold opacity-100">Warning:</span> 
                Inference suggests {result.level.toLowerCase()} heart stress.
              </p>
           </div>
           <div className="p-3 bg-white/5 rounded-lg border border-white/5 flex gap-3 items-center">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <p className="text-[10px] text-slate-400 leading-relaxed uppercase tracking-tight">
                <span className="text-white font-bold">Trend:</span>
                Voting consensus is {result.overallRisk > 0.5 ? 'ELEVATED' : 'STABLE'}.
              </p>
           </div>
        </div>
      </motion.div>

      {/* Ensemble Breakdown */}
      <div className="grid grid-cols-1 gap-4">
         <div className="flex items-center gap-2 px-2">
            <BrainCircuit className="w-4 h-4 text-blue-500" />
            <h4 className="text-[10px] uppercase tracking-[0.25em] text-slate-500 font-black">Neural Ensemble Voting Pattern</h4>
         </div>
         
         <div className="space-y-3">
           {result.contributions.map((m, idx) => (
             <motion.div 
              key={idx}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * idx }}
              className="bg-white/5 backdrop-blur-md border border-white/5 p-4 rounded-xl flex items-center gap-6 hover:bg-white/10 transition-colors cursor-default"
             >
                <div className="w-12 h-12 rounded-xl border border-white/10 flex items-center justify-center bg-slate-900/50 font-mono text-[10px] text-slate-400">
                  {Math.round(m.weight * 100)}%
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-white tracking-tight italic uppercase">{m.modelName}</span>
                    <span className="text-[10px] font-mono text-slate-500">{m.prediction.toFixed(2)}</span>
                  </div>
                  <div className="relative h-1 bg-slate-900/50 rounded-full mb-2">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${m.prediction * 100}%` }}
                      className="absolute inset-y-0 left-0 bg-blue-500 rounded-full"
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium leading-tight italic">
                    {m.reason}
                  </p>
                </div>
             </motion.div>
           ))}
         </div>
      </div>
    </div>
  );
}

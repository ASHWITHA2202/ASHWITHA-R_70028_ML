/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { History, CheckCircle, XCircle, Search } from 'lucide-react';

export default function TestRuns() {
  const runs = [
    { id: 'TR-902', name: 'UCI Validation A', status: 'Passed', accuracy: '94.2%', date: '2026-04-22' },
    { id: 'TR-881', name: 'Real-time Node 4', status: 'Passed', accuracy: '91.8%', date: '2026-04-23' },
    { id: 'TR-870', name: 'Stress Test Gamma', status: 'Warning', accuracy: '88.5%', date: '2026-04-24' },
  ];

  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 select-none pointer-events-none">
        <span className="text-[30px] font-black opacity-5 italic leading-none text-white uppercase">History</span>
      </div>

      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-blue-400" />
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">In-Situ Test Runs</h3>
        </div>
        <Search className="w-3 h-3 text-slate-600" />
      </div>

      <div className="space-y-4 relative z-10">
        {runs.map((run) => (
          <div key={run.id} className="flex items-center justify-between group cursor-pointer p-2 rounded-lg hover:bg-white/5 transition-all">
            <div className="flex items-center gap-3">
              {run.status === 'Passed' ? (
                <CheckCircle className="w-3 h-3 text-emerald-500 shadow-[0_0_8px_rgba(52,211,153,0.3)]" />
              ) : (
                <XCircle className="w-3 h-3 text-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.3)]" />
              )}
              <div>
                <div className="text-[9px] font-mono text-slate-600 uppercase tracking-tighter">{run.id}</div>
                <div className="text-[10px] font-black text-white group-hover:text-blue-400 transition-colors uppercase tracking-tight">
                  {run.name}
                </div>
              </div>
            </div>
            <div className="text-right">
               <div className="text-[10px] font-mono text-slate-400">{run.accuracy}</div>
               <div className="text-[9px] text-slate-700 uppercase font-bold tracking-tighter">{run.date}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

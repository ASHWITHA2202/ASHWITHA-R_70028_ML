/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from "@google/genai";
import { PatientData, PredictionResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getMedicalInsights(data: PatientData, result: PredictionResult) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        Analyze this heart disease prediction scenario for a medical software demonstration.
        
        Patient Data: ${JSON.stringify(data)}
        Prediction Result: ${JSON.stringify(result)}

        Provide high-level insights in JSON format with the following structure:
        {
          "medicalContext": "A brief clinical explanation of why these risk factors matter.",
          "innovativeExtensions": ["3-4 futuristic automation or extension ideas for this app (e.g. IoT integration, real-time arterial monitoring)."],
          "caseStudyScenario": "A short hypothetical case study where this ensemble model saved the day.",
          "optimizationTricks": ["Suggestions for improving the model's accuracy or user experience."]
        }
      `,
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return null;
  }
}

export async function getSimulationScenario() {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        Generate a real-world simulation scenario for a heart disease prediction tool.
        Include a hypothetical User Input, System Response, and Result.
        Focus on how "Ensemble Learning" makes it better than a single model.
      `
    });
    return response.text;
  } catch (error) {
    return "Error generating simulation.";
  }
}
